package almoxarifado.classes.logico;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

/**
 *
 * @author Diego Neves Isidoro
 */
public class Produto {
    private String nome;
    private String marca;
    private int qtdMinima;
    private int qtdAtual;
    private int qtdMaxima;
    private double preco;
    

    public Produto(String nome, String marca){
        this.nome = nome;        
        this.marca = marca;
    }
        
    public Produto() {
		
	}

	public int getQtdMinima() {
		return qtdMinima;
	}
    
	public void setQtdMinima(int qtdMinima) {
		this.qtdMinima = qtdMinima;
	}
	
	public int getQtdAtual() {
		return qtdAtual;
	}
	
	public void setQtdAtual(int qtdAtual) {
		this.qtdAtual = qtdAtual;
	}
	
	public int getQtdMaxima() {
		return qtdMaxima;
	}
	
	public void setQtdMaxima(int qtdMaxima) {
		this.qtdMaxima = qtdMaxima;
	}

    public String getNome(){
        return this.nome;
    }
    
    public String getMarca(){
        return this.marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
    
    public void insereProduto()
    {
        Conexao conn = new Conexao();
        conn.conecta();
        String sql = "insert into Produto values (proCodigo.nextval,'"+this.nome+"','"+this.marca+")";
        conn.executaSQL(sql);
        conn.desconecta();
    }
    public void alterarProduto(int proCodigo, int i)
    {
        int soma = 0;
        Conexao conn = new Conexao();
        conn.conecta();
        String sqlex = "select * from Produto where proCodigo = "+proCodigo+"";
        ResultSet result = conn.executaBusca(sqlex);
        if(result != null)
        {
            try
            {
                soma = this.qtdAtual + result.getInt("proQtdAtual");
            }
            catch(SQLException teste){
                System.out.println("err9");
            }
            String sql = "update Produto set proNome = '"+this.nome+"', forMarca = '"+this.marca+"', proQtdAtual = "+soma+" where proCodigo = "+proCodigo+"";
            conn.executaSQL(sql);
        }
        conn.desconecta();
    }
    

    
    
    public void excluirProduto(String nome)
    {
        Conexao conn = new Conexao();
        conn.conecta();
        String sql = "delete from Produto where proNome = '"+nome+"'";
        conn.executaSQL(sql);
        conn.desconecta();
    }
    public ResultSet buscaProduto(String nome)
    {
        Conexao conn = new Conexao();
        conn.conecta();
        String sql = "select * from Produto where proNome like '%"+nome+"%'";
        ResultSet result = conn.executaBusca(sql);
        return result;
    }
}
