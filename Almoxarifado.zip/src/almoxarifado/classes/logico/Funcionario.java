package almoxarifado.classes.logico;

import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class Funcionario extends Usuario{
    
    /*Sobrecarga de construtores*/
    public Funcionario(){		
    }
    public Funcionario(String nome, String login, String senha)
    {	
        super(nome, login, senha);
    }
    /*Chamo o metodo da classe pai e mando o parametro recebido*/
    public void setSexo(String sexo){
    	super.setSexo(sexo);    	
    }
	
    public void insereFuncionario(int tipCodigo)
    {
        super.insereUsuario(tipCodigo);
    }
    public void alterarFuncionario(int usuCodigo, int tipCodigo)
    {
        super.alterarFornecedor(usuCodigo, tipCodigo);
    }
    public void excluirFuncionario(int usuCodigo)
    {
        Conexao conn = new Conexao();
        conn.conecta();
        String sql = "delete from Usuario where usuCodigo = '"+usuCodigo+"'";
        conn.executaSQL(sql);
        conn.desconecta();
    }
    public ResultSet buscaFuncionario(String nome)
    {
        Conexao conn = new Conexao();
        conn.conecta();
        String sqle = "commit";
        conn.executaBusca(sqle);
        String sql = "select * from Usuario where usuNome like '%"+nome+"%'";
        ResultSet result = conn.executaBusca(sql);
        return result;
    }
}