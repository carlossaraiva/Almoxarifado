package almoxarifado.classes.logico;
/**
 *
 * @author Diego Neves Isidoro
 */
public class Almoxarifado extends Usuario {
    public Almoxarifado(){};

    public Almoxarifado(String nome, int numIdentificacao, String senha, String login) {
        super(nome, senha, login);
    }
    
}
