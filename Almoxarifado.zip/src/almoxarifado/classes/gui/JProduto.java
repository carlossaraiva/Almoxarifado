package almoxarifado.classes.gui;
import almoxarifado.classes.*;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import almoxarifado.classes.logico.*;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class JProduto extends JPanel implements ActionListener, ListSelectionListener {

	private static final long serialVersionUID = 1L;


	private DefaultListModel modelProdutos = new DefaultListModel();
	private DefaultListModel buscaProdutos = new DefaultListModel();
	
	private JTextField txtNomeProduto;
	private JTextField txtMarca;
	private JTextField textField;	
	private JList listProduto;	
	private JButton btnAdicionar;
	private JButton btnLimpar;
	private JButton btnExcluir;
	private JButton btnAlterar;
	
	private JLabel lblNomeProduto;
	private JLabel lblMarca;
	private JScrollPane scrollPane;
        
        private DefaultComboBoxModel<String> cboModelProdutos = new DefaultComboBoxModel<String>();
        private JComboBox<String> cboProduto;
	
	//Metodo que atuliza no banco os resultados
	public void atualizaProduto(String nome)
	{
		//Limpo o objeto
		modelProdutos.clear();
		//Instancio objeto
		Produto pro = new Produto();
		//Executo uma busca sem nenhum valor para retornar tudo que existir no banco e guardo em uma variavel
		ResultSet result = pro.buscaProduto(""+nome+"");
		try
		{
			while(result.next())
			{
				//Exponho o elemento no objeto selecionando so a coluna nome que o interessante neste caso
				modelProdutos.addElement(result.getString("proNome"));
			}
		}
		catch(SQLException sqlex)
		{
			//Se ocorrer um erro este apare�era nesta excessao
			JOptionPane.showMessageDialog(null, "Erro "+sqlex.getLocalizedMessage()+".");
		}
	}	
	//Construtores
	public JProduto() {		
		setPainel();		
	}
	//Setters e getters
	
	private void setPainel(){
		setLayout(null);		
		
		btnAdicionar = new JButton("Adicionar");
		btnAdicionar.setBounds(10, 372, 89, 23);
		add(btnAdicionar);
		btnAdicionar.addActionListener(this);
				
		txtNomeProduto = new JTextField();
		txtNomeProduto.setBounds(10, 64, 220, 20);
		add(txtNomeProduto);
		txtNomeProduto.setColumns(10);
		
		txtMarca = new JTextField();
		txtMarca.setBounds(10, 116, 220, 20);
		add(txtMarca);
		txtMarca.setColumns(10);
				
		btnExcluir = new JButton("Excluir");
		btnExcluir.setBounds(429, 360, 89, 23);
		btnExcluir.addActionListener(this);
		btnExcluir.setEnabled(false);
		add(btnExcluir);
		
		btnAlterar = new JButton("Alterar");
		btnAlterar.setBounds(529, 360, 89, 23);
		btnAlterar.addActionListener(this);
		btnAlterar.setEnabled(false);
		add(btnAlterar);	
		
		btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(this);
		btnLimpar.setBounds(123, 372, 89, 23);
					
		lblNomeProduto = new JLabel("Nome do produto:");
		lblNomeProduto.setBounds(10, 39, 89, 14);
				
		lblMarca = new JLabel("Marca:");
		lblMarca.setBounds(10, 95, 46, 14);
		
		atualizaProduto("");
				
		textField = new JTextField();
		textField.addFocusListener(new FocusAdapter() {
			
		});
		//Quando digitado algo no txt o evento e disparado es por sua vez chama outro
		textField.addKeyListener
		(
				new KeyAdapter() 
				{	
					@Override
					public void keyReleased(KeyEvent arg0) 
					{
						atualizaProduto(textField.getText());
					}
				}
		);
		textField.setBounds(429, 64, 189, 20);
		
		textField.setColumns(10);
		
		add(lblNomeProduto);
		add(lblMarca);
		add(textField);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(429, 94, 189, 253);
		add(scrollPane);
                
                cboProduto = new JComboBox<String>(cboModelProdutos);
		cboProduto.setBounds(80, 186, 132, 20);
		add(cboProduto);
		
		listProduto = new JList(modelProdutos);
		scrollPane.setViewportView(listProduto);
		listProduto.addListSelectionListener(this);
		add(btnLimpar);
	
	}
	
	//Listeners
	public void valueChanged(ListSelectionEvent e){
		
		System.out.println(listProduto.getSelectedIndex());
	    if (e.getValueIsAdjusting() == false) {

	        if (listProduto.getSelectedIndex() == -1) {
	        //No selection, disable fire button.
	            btnExcluir.setEnabled(false);
	            btnAlterar.setEnabled(false);

	        } else {
	        //Selection, enable the fire button.
	            btnExcluir.setEnabled(true);
	            btnAlterar.setEnabled(true);
	        }		    
	    }		
	    if (e.getSource() == listProduto){
	    	String esc = (String)listProduto.getSelectedValue();
	    	Produto pro = new Produto();
	    	ResultSet result = pro.buscaProduto(esc);
	    	try
	    	{
	    		while(result.next()){
	    			txtNomeProduto.setText(result.getString("proNome"));
	    		}		
	    	}
	    	catch(SQLException sqlex)
	    	{
	    		JOptionPane.showMessageDialog(null, "Erro "+sqlex.getLocalizedMessage()+".");
	    	}
	    }
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == btnAdicionar)
		{
			if(txtNomeProduto.getText().contentEquals(""))
			{
				JOptionPane.showMessageDialog(null, "N�o pode ser deixar campos vazios.");
				txtNomeProduto.setCursor(null);
			}
			else
			{
				String nom=""; 
				Produto pro = new Produto();
				ResultSet result = pro.buscaProduto(txtNomeProduto.getText());
				try
				{
					while(result.next())
					{
						nom = result.getString("proNome");
					}
				}
				catch(SQLException sqlex)
				{
					JOptionPane.showMessageDialog(null, "Erro "+sqlex.getLocalizedMessage()+".");
				}
				
				if(nom.contentEquals(txtNomeProduto.getText()))
				{
					JOptionPane.showMessageDialog(null,"J� existe produto com este nome.");
				}
				else
				{
					//pro.insereProduto();
					atualizaProduto("");
					JOptionPane.showMessageDialog(null,"Produto adicionado com sucesso!");
					txtNomeProduto.setText(null);
					txtMarca.setText(null);
				}
			}
		}		
		if(e.getSource() == btnExcluir){
			int esc = JOptionPane.showConfirmDialog(null, "Voc� tem certeza que deseja deletar este produto ?");
			if(esc == 0)
			{
				Produto pro = new Produto();
				//pro.excluirFornecedor(txtNomeProduto.getText());
				atualizaProduto("");
				txtNomeProduto.setText(null);
				txtMarca.setText(null);
			}
			else
			{
				atualizaProduto("");
			}
		}
		if(e.getSource() == btnAlterar){
			int esc = JOptionPane.showConfirmDialog(null, "Voc� tem certeza que deseja alterar este produto ?");
			if(esc == 0)
			{
				//Produto pro = new Produto(txtNomeProduto.getText(), 1,txtMarca.getText(), txtNomeProduto.getText(), txtMarca.getText());
				//pro.alterarFornecedor();
				atualizaProduto("");
				txtNomeProduto.setText(null);
				txtMarca.setText(null);
			}
			else
			{
				atualizaProduto("");
			}
		}
		if(e.getSource() == btnLimpar){
			txtNomeProduto.setText(null);
			txtMarca.setText(null);			
		}
	}
}