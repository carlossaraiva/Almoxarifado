package almoxarifado.nao.implementados;

public interface Controle {

}
