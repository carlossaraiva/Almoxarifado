

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import almoxarifado.classes.gui.JDesktop;

public class Principal extends JFrame{ 

	private static final long serialVersionUID = 1L;
	
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
				//Crio um novo frame, que neste caso ser� o programa principal.
				Principal principal = new Principal();
				
				//UIManager para manter o estilo de bot�es e janelas compat�veis com o sistema operacional em uso.
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				SwingUtilities.updateComponentTreeUI(principal);
				
				//Instancio a classe JDesktop que contem v�rios elementos como Internal frames e a barra de menus.
				JDesktop desktop = new JDesktop();
				desktop.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				desktop.setBounds(80, 80, 1290, 720);
				
	}
}